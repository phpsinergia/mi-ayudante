<?php
declare(strict_types=1);
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;

$configuracion = require (dirname(__DIR__) . '/phpsinergia/arranque.php');

$app = AppFactory::create();
$app->setBasePath("/{$configuracion->leer('DIR_APP')}");

$app->get('/', function (Request $request, Response $response) use ($configuracion) {
    $t = $configuracion->obtenerTraductor();
    $t->asignarDominio('aplicacion');
    $response->getBody()->write("{$t->_('Bienvenido-a-la-aplicacion')} - {$t->_('Debe-autenticarse-para-acceder-a-este-recurso', true)} - {$configuracion->leer('DIR_APP')}");
    return $response;
});

$app->run();